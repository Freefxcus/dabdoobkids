export const baseUrl = {
  // production: "",
  production: "https://api-staging.dabdoobkidz.com", // staging
};
