
export default function WishListCard() {
  return (
    <div className="">
        <img style={{height : "309px"}} src="/test.jpg" alt="wishlistImage" />
        <div>
            <h4>Spring Collection</h4>
        </div>
    </div>
  )
}
